/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelos;

/**
 *
 * @author famze
 */
public class MAritmetico {
    public boolean sonIguales(int num1, int num2){
        return num1 == num2;
    }
    
    public boolean sonIguales(double num1, double num2){
        return num1 == num2;
    }
    
    public boolean sonIguales(int num1, double num2){
        return num1 == num2;
        
    }
    
    /**
     * Verifica sidos numeros reales son iguales
     * @param num1
     * @param num2
     * @return 
     */
    
    public boolean sonIguales(String num1, String num2){
        return num1.equals(num2);
    }
    
}
