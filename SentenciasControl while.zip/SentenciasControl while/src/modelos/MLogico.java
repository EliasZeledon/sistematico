/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelos;

/**
 *
 * @author famze
 */
public class MLogico {
    /**
     * Verifica si dos numeros enteros son iguales
     * @param num1
     * @param num2
     * @return 
     */
    public boolean sonIguales(int num1, int num2){
        return num1 == num2;
    }
    
    public double numeroMayor (double num1, double num2 ){
        
        if (num1>num2)return num1;
        return num2;
    }
    
    //PUBLIC  

    public boolean sonIguales(double num1, double num2) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
}
